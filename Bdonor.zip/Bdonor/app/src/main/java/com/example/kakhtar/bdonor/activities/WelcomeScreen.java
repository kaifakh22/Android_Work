package com.example.kakhtar.bdonor.activities;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.kakhtar.bdonor.R;
import com.example.kakhtar.bdonor.adapters.WelcomePagerAdapter;

public class WelcomeScreen extends AppCompatActivity implements ViewPager.OnPageChangeListener{
    int[] layouts;
    ViewPager viewPager;
    TextView[] dots;
    LinearLayout dotsLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        // Making notification bar transparent
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        if(Build.VERSION.SDK_INT>19){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }

        setContentView(R.layout.activity_welcome_screen);
        dotsLayout = (LinearLayout)findViewById(R.id.dotsLayout);
        addBottonDots(0);
        //hello
        layouts = new int[]{R.layout.welcome_screen1,R.layout.welcome_screen2};

        viewPager = (ViewPager)findViewById(R.id.vp_welcome);
        viewPager.setOnPageChangeListener(this);
        WelcomePagerAdapter welcomePagerAdapter = new WelcomePagerAdapter(this,layouts);
        viewPager.setAdapter(welcomePagerAdapter);
    }

    private void addBottonDots(int currentPage){
        dotsLayout.removeAllViews();
        int[] colorsActive = getResources().getIntArray(R.array.active_color);
        int[] colorsInactive = getResources().getIntArray(R.array.inactive_color);
        dots = new TextView[colorsActive.length];

        for(int i = 0 ; i<colorsActive.length;i++ ){
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(40);
            dots[i].setTextColor(colorsInactive[currentPage]);
            dotsLayout.addView(dots[i]);
        }

        dots[currentPage].setTextColor(colorsActive[currentPage]);
    }



    @Override
    public void onPageSelected(int i) {
       addBottonDots(i);
    }

    @Override
    public void onPageScrollStateChanged(int i) {

    }

    @Override
    public void onPageScrolled(int i, float v, int i1) {

    }
}
